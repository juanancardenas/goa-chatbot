package es.upm.api.domain.services.aireply;

import es.upm.api.configurations.ChatbotAiProperties;
import es.upm.api.domain.enums.ConversationProfileType;
import es.upm.api.domain.model.Conversation;
import es.upm.api.domain.model.ai.ChatbotAiRequest;
import es.upm.api.domain.model.ai.ChatbotAiResponse;
import es.upm.api.domain.model.platform.ChatbotPlatformContext;
import es.upm.api.domain.ports.out.ChatbotAiClient;
import es.upm.api.domain.services.conversation.ChatbotMessageService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ChatbotAiReplyService {

    private final ChatbotAiClient chatbotAiClient;
    private final ChatbotAiProperties chatbotAiProperties;
    private final ChatbotMessageService chatbotMessageService;

    public ChatbotAiReplyService(
            ChatbotAiClient chatbotAiClient,
            ChatbotAiProperties chatbotAiProperties,
            ChatbotMessageService chatbotMessageService
    ) {
        this.chatbotAiClient = chatbotAiClient;
        this.chatbotAiProperties = chatbotAiProperties;
        this.chatbotMessageService = chatbotMessageService;
    }

    public String generateConfiguredAssistantReply(
            Conversation conversation,
            ConversationProfileType profile,
            String userMessage,
            String baseReply,
            Optional<ChatbotPlatformContext> platformContext
    ) {
        if (!this.chatbotAiProperties.isEnabled()) {
            return baseReply;
        }

        try {
            ChatbotAiRequest aiRequest = ChatbotAiRequest.builder()
                    .conversationId(conversation.getId())
                    .userId(conversation.getUserId())
                    .userMessage(this.buildAiUserMessage(conversation, userMessage, baseReply, platformContext))
                    .basePrompt(this.chatbotAiProperties.getBasePrompt())
                    .roleProfile(profile.name())
                    .conversationType(conversation.getType())
                    .platformContext(this.buildPlatformContextForPrompt(platformContext))
                    .recentMessages(
                            this.chatbotMessageService.readRecentMessagesForPrompt(
                                    conversation.getId(),
                                    this.chatbotAiProperties.getMaxContextMessages()
                            )
                    )
                    .model(this.chatbotAiProperties.getModel())
                    .maxOutputTokens(this.chatbotAiProperties.getMaxOutputTokens())
                    .temperature(this.chatbotAiProperties.getTemperature())
                    .documentsAvailable(this.chatbotAiProperties.isDocumentsAvailable())
                    .build();

            ChatbotAiResponse aiResponse = this.chatbotAiClient.generate(aiRequest);

            if (aiResponse == null || !aiResponse.isSuccessful() || aiResponse.getContent() == null
                    || aiResponse.getContent().isBlank()) {
                return baseReply;
            }

            return aiResponse.getContent().trim();
        } catch (RuntimeException ignored) {
            return baseReply;
        }
    }

    private String buildAiUserMessage(
            Conversation conversation,
            String userMessage,
            String baseReply,
            Optional<ChatbotPlatformContext> platformContext
    ) {
        StringBuilder builder = new StringBuilder();

        builder.append("Mensaje del usuario: ")
                .append(this.safeText(userMessage, ""))
                .append(System.lineSeparator())
                .append(System.lineSeparator());

        builder.append("Respuesta base funcional que debes respetar y mejorar si procede: ")
                .append(this.safeText(baseReply, ""))
                .append(System.lineSeparator())
                .append(System.lineSeparator());

        builder.append("Tipo de conversacion: ")
                .append(this.safeText(conversation.getType(), "GENERAL"))
                .append(System.lineSeparator());

        if (conversation.getEngagementLetterId() != null && !conversation.getEngagementLetterId().isBlank()) {
            builder.append("engagementLetterId asociado: ")
                    .append(conversation.getEngagementLetterId())
                    .append(System.lineSeparator());
        }

        platformContext.ifPresent(context -> builder
                .append(System.lineSeparator())
                .append("Contexto de plataforma disponible: ")
                .append(System.lineSeparator())
                .append(this.buildPlatformContextForPrompt(Optional.of(context)))
        );

        return builder.toString().trim();
    }

    private String buildPlatformContextForPrompt(Optional<ChatbotPlatformContext> platformContext) {
        if (platformContext.isEmpty()) {
            return "";
        }

        ChatbotPlatformContext context = platformContext.get();
        StringBuilder builder = new StringBuilder();

        builder.append("EngagementLetterId: ")
                .append(this.safeText(context.getEngagementLetterId(), "no disponible"))
                .append(System.lineSeparator());

        builder.append("Titular/cliente: ")
                .append(this.safeText(context.getOwnerDisplayName(), "no disponible"))
                .append(System.lineSeparator());

        if (context.getProcedureTitles() != null && !context.getProcedureTitles().isEmpty()) {
            builder.append("Procedimientos: ")
                    .append(String.join(", ", context.getProcedureTitles()))
                    .append(System.lineSeparator());
        }

        if (context.getRecentEventSummaries() != null && !context.getRecentEventSummaries().isEmpty()) {
            builder.append("Eventos recientes: ")
                    .append(String.join(" | ", context.getRecentEventSummaries()))
                    .append(System.lineSeparator());
        }

        if (context.getLegalTaskSummaries() != null && !context.getLegalTaskSummaries().isEmpty()) {
            builder.append("Tareas legales: ")
                    .append(String.join(" | ", context.getLegalTaskSummaries()))
                    .append(System.lineSeparator());
        }

        if (context.getSourcesSummary() != null && !context.getSourcesSummary().isEmpty()) {
            builder.append("Fuentes: ")
                    .append(String.join(", ", context.getSourcesSummary()))
                    .append(System.lineSeparator());
        }

        return builder.toString().trim();
    }

    private String safeText(String value, String fallback) {
        if (value == null || value.isBlank()) {
            return fallback;
        }

        return value.trim();
    }
}
