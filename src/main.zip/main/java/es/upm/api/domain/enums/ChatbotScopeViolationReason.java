package es.upm.api.domain.enums;

public enum ChatbotScopeViolationReason {
    OUT_OF_CASE_SCOPE,
    MISSING_CASE_CONTEXT,
    LEGAL_BINDING_ADVICE_REQUESTED,
    EMOTIONAL_DISTRESS,
    UNSUPPORTED_FACTUAL_ASSERTION,
    AMBIGUOUS_CONTEXT,
    OUT_OF_DOMAIN
}
