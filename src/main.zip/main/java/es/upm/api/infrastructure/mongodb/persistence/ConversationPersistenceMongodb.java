package es.upm.api.infrastructure.mongodb.persistence;

import es.upm.api.domain.enums.ConversationStatus;
import es.upm.api.domain.exceptions.NotFoundException;
import es.upm.api.domain.model.Conversation;
import es.upm.api.domain.ports.out.ConversationGateway;
import es.upm.api.infrastructure.mongodb.daos.ConversationRepository;
import es.upm.api.infrastructure.mongodb.entities.ConversationEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ConversationPersistenceMongodb implements ConversationGateway {
    private final ConversationRepository conversationRepository;

    @Autowired
    public ConversationPersistenceMongodb(ConversationRepository conversationRepository) {
        this.conversationRepository = conversationRepository;
    }

    @Override
    public Conversation readById(String id) {
        return this.conversationRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("conversationId no corresponde a una conversacion existente"))
                .toConversation();
    }

    @Override
    public List<Conversation> findByUserId(String userId) {
        return this.conversationRepository.findByUserIdOrderByCreatedAtDesc(userId).stream()
                .map(ConversationEntity::toConversation)
                .toList();
    }

    @Override
    public Optional<Conversation> findContextualConversation(
            String userId,
            String engagementLetterId,
            String type
    ) {
        return this.conversationRepository
                .findByUserIdAndEngagementLetterIdAndType(userId, engagementLetterId, type)
                .map(ConversationEntity::toConversation);
    }

    @Override
    public Optional<Conversation> findActiveContextualConversation(
            String userId,
            String engagementLetterId,
            String type
    ) {
        return this.conversationRepository
                .findByUserIdAndEngagementLetterIdAndTypeAndStatus(
                        userId,
                        engagementLetterId,
                        type,
                        ConversationStatus.ACTIVE
                )
                .map(ConversationEntity::toConversation);
    }

    @Override
    public List<Conversation> findByUserIdAndTypeOrderByCreatedAtDesc(
            String userId,
            String type
    ) {
        return this.conversationRepository.findByUserIdAndTypeOrderByCreatedAtDesc(userId, type)
                .stream()
                .map(ConversationEntity::toConversation)
                .toList();
    }

    @Override
    public List<Conversation> findByUserIdAndEngagementLetterIdAndTypeOrderByCreatedAtDesc(
            String userId,
            String engagementLetterId,
            String type
    ) {
        return this.conversationRepository
                .findByUserIdAndEngagementLetterIdAndTypeOrderByCreatedAtDesc(userId, engagementLetterId, type)
                .stream()
                .map(ConversationEntity::toConversation)
                .toList();
    }

    @Override
    public void create(Conversation conversation) {
        ConversationEntity entity = ConversationEntity.fromConversation(conversation);
        this.conversationRepository.save(entity);
    }

    @Override
    public void update(Conversation conversation) {
        ConversationEntity entity = ConversationEntity.fromConversation(conversation);
        this.conversationRepository.save(entity);
    }

    @Override
    public void delete(String conversationId) {
        this.conversationRepository.deleteById(conversationId);
    }
}
